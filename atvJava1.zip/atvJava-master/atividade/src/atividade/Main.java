package atividade;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);

		/*
		 * QUESTÃO NÚMERO 1 
		 * int nmr1, nmr2, nmr3, media;
		 * 
		 * System.out.println("Digite um valor");
		 * 
		 * nmr1 = input.nextInt();
		 * 
		 * System.out.println("Digite outro valor");
		 * 
		 * nmr2 = input.nextInt();
		 * 
		 * System.out.println("Digite mais valor");
		 * 
		 * nmr3 = input.nextInt();
		 * 
		 * media = nmr1 + nmr2 + nmr3 / 3;
		 * 
		 * System.out.println("A média aritmética é: " + media);
		 */

		/*
		 * QUESTÃO NÚMERO 2 
		 * int idade, anoNascimento, anoAtual, futuro;
		 * 
		 * System.out.println("Digite o ano do seu nascimento: "); anoNascimento =
		 * input.nextInt();
		 * 
		 * System.out.println("Digite o ano atual: "); anoAtual = input.nextInt();
		 * 
		 * idade = anoAtual - anoNascimento;
		 * 
		 * futuro = 2050 - anoNascimento;
		 * 
		 * System.out.println("Sua idade é " + idade + "anos");
		 * System.out.println("Em 2050 você terá " + futuro + "anos");
		 */
		/*
		 * QUESTÃO NÚMERO 3 
		 * double cotacao, real, dolar, valorEmDolar, valorEmReal;
		 * System.out.println("Digite a cotação do Dólar em Real: "); cotacao =
		 * input.nextDouble();
		 * 
		 * System.out.println("Digite quanto você têm em dolár"); valorEmDolar =
		 * input.nextDouble(); valorEmReal = cotacao * valorEmDolar;
		 * 
		 * System.out.println("Você têm R$" + valorEmReal);
		 */
		/*
		 * QUESTÃO NÚMERO 4 
		 * double salario, novoSalario, salarioFinal;
		 * 
		 * System.out.println("Digite seu salário: "); salario = input.nextDouble();
		 * 
		 * novoSalario = salario * 0.25; salarioFinal = salario + novoSalario;
		 * 
		 * System.out.println("Seu novo salário com reajuste é: " + salarioFinal);
		 */
		/*
		 * QUESTÃO NÚMERO 5 
		 * double areaMaior, areaMenor, area;
		 * 
		 * System.out.println("Digite a área Maior do Losango: "); areaMaior =
		 * input.nextDouble();
		 * 
		 * System.out.println("Digite a área Menor do Losango: "); areaMenor =
		 * input.nextDouble();
		 * 
		 * area = (areaMaior * areaMenor) / 2;
		 * 
		 * System.out.println("A área do Losango é: " + area);
		 */
		/*
		 * QUESTÃO NÚMERO 6 
		 * double celsius, fahrenheit;
		 * 
		 * System.out.println("Digite a temperatura em °C (Celsius): "); celsius =
		 * input.nextDouble();
		 * 
		 * fahrenheit = (celsius * 1.8) + 32;
		 * 
		 * System.out.println("A temperatura " + celsius + "°C em Fahrenheit é " +
		 * fahrenheit + "°F");
		 */
		/*
		 * QUESTÃO NÚMERO 7
		 * double salarioMinimo, salarioFuncionario, qtdSalarioMinimo;
		 * 
		 * System.out.println("Digite o valor do salário mínimo atual: "); salarioMinimo
		 * = input.nextDouble();
		 * 
		 * System.out.println("Digite o salário do funcionário: "); salarioFuncionario =
		 * input.nextDouble();
		 * 
		 * qtdSalarioMinimo = salarioFuncionario / salarioMinimo;
		 * 
		 * System.out.printf("O funcionário recebe %.2f salários mínimos.",
		 * qtdSalarioMinimo);
		 */
		/*
		 * QUESTÃO NÚMERO 8 
		 * System.out.println("Digite seu peso em Kgs: "); double peso
		 * = input.nextDouble();
		 * 
		 * double pesoEngordar = peso * 1.15; double pesoEmagrecer = peso * 0.8;
		 * 
		 * System.out.println("Se você engordar 15% do seu peso atual terá: " +
		 * pesoEngordar + "Kgs");
		 * System.out.println("Se você emagrecer 20% do seu peso atual terá: " +
		 * pesoEmagrecer + "Kgs");
		 */
		/*
		QUESTÃO NÚMERO 9
		System.out.println("Digite o primeiro cateto (a): ");
		double catetoA = input.nextDouble();
		System.out.println("Digite o segundo cateto (b): ");
		double catetoB = input.nextDouble();
		double hipotenusa = Math.sqrt(Math.pow(catetoA, 2) + Math.pow(catetoB, 2));
		System.out.println("A hipotenusa do triângulo é " + hipotenusa);
		*/
		/*
		 * QUESTÃO NÚMERO 10 
		 * System.out.println("Digite o Raio: "); double raio =
		 * input.nextDouble();
		 * 
		 * double comprimentoEsfera = 2 * Math.PI * raio; double areaEsfera = Math.PI *
		 * Math.pow(raio, 2); double volumeEsfera = (3.0 / 4.0) * Math.PI *
		 * Math.pow(raio, 3);
		 * 
		 * System.out.printf("O comprimento da Esfera é: %.2f \n", comprimentoEsfera);
		 * System.out.printf("A área da Esfera é: %.2f \n", areaEsfera);
		 * System.out.printf("O volume da Esfera é: %.2f", volumeEsfera);
		 */
		/*
		 * QUESTÃO NÚMERO 11 
		 * System.out.println("Informe o número inteiro: "); int nmr =
		 * input.nextInt();
		 * 
		 * for (int i = 0; i <= 10; i++) { int resultado = nmr * i;
		 * System.out.println(nmr + " x " + i + " = " + resultado);
		 * 
		 * }
		 */
	}

}
